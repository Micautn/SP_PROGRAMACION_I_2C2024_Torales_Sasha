from claseEmpleado import *
from claseVehiculo import *
import os
import json
from utils import *
import re
import csv


def get_empleado():
    aux_list_empleados = []
    with open(path_empleados, 'r') as mi_archivo:
        next(mi_archivo)           #aca salteo el encabezado
        for linea in mi_archivo:                 
            aux = linea.strip().split(';')
            id_empleado = int(aux[0])
            apellido_nombre = aux[1]
            salario = float(aux[2])
            dni = int(aux[3])
            telefono = aux[4].strip()  
            # Crear objeto Empleado y agregar a la lista
            empleado = Empleado(apellido_nombre, salario, dni, telefono)
            empleado.id = id_empleado
            aux_list_empleados.append(empleado)
    
    return aux_list_empleados

def guardar_empleado(lista_nueva:list[Empleado]):
    with open(path_empleados, mode="w", newline="") as file:
        writer = csv.writer(file, delimiter=';')
        writer.writerow(['id', 'apellido_nombre', 'salario', 'dni', 'telefono'])  # escribo encabezados
        for empleado in lista_nueva:
            writer.writerow([empleado.id, empleado.apellido_nombre, empleado.salario, empleado.dni, empleado.telefono])

def get_vehiculo():
    try:
        if os.path.exists(path_vehiculos):
            with open(path_vehiculos, 'r') as file:
                data = json.load(file)
                lista_vehiculos = []
                for item in data:
                    vehiculo = Vehiculo(
                        item['Marca'],
                        item['Modelo'],
                        item['Anio'],
                        item['Color'],
                        item['Patente'],
                        item['Propietario']
                    )
                    vehiculo.ID = item['ID']
                    lista_vehiculos.append(vehiculo)
                print(f"[Aviso JSON] Carga exitosa de archivo {path_vehiculos}")
                input('Continuar... ')
                
                return lista_vehiculos
        else:
            print(f"[Aviso JSON] No se encontro el archivo {path_vehiculos}")
            input('Continuar... ')
            return []
        
    except Exception as e:
        print(f"[ERROR JSON]: {e}")
        input()
        return False

def guardar_vehiculo(lista_vehiculos:list[Vehiculo]):
    try:
        with open(path_vehiculos, 'w') as mi_archivo:
            json.dump([vehiculo.parse_json() for vehiculo in lista_vehiculos], mi_archivo, indent=4)
        return True
    except Exception as e:
        print(f"[ERROR JSON]: {e}")
        return False

def ordenamiento_anio(lista_vehiculos:list[Vehiculo]):
    lista_aux = burbujeoo(lista_vehiculos, criterio_anio)
    return lista_aux

def criterio_anio(vehiculo:Vehiculo):
    return vehiculo.Anio

def ordenamiento_salario(lista_empleados:list[Empleado]):
    lista_aux = burbujeoo(lista_empleados, criterio_salario)
    return lista_aux

def criterio_salario(empleado:Empleado):
    return empleado.salario
def listar_empleados(lista_empleados:list[Empleado]):
    for empleado in lista_empleados:
        print(empleado)

def listar_vehiculos(lista_vehiculos:list[Vehiculo]):
    for v in lista_vehiculos:
        print(v)

def validar_telefono(telefono):
    # Expresión regular para el formato "11-NNNN-NNNN"
    patron = r'^11-\d{4}-\d{4}$'
    
    # Validar el número de teléfono con el patrón
    if re.match(patron, telefono):
        return True
    else:
        return False

def validar_nombre_apellido(apellido_nombre):
    patron = re.compile(r'^[A-Za-zÁÉÍÓÚáéíóúÑñ\' -]+$')
    if patron.match(apellido_nombre):
        return True
    else:
        return False

def alta_empleado(lista_empleados:list[Empleado])->Empleado:
    apellido_nombre = input("Deme su apellido y nombre: ").capitalize()
    while validar_nombre_apellido(apellido_nombre) == False:
        apellido_nombre = input('[error]Ingrese apellido y nombre valido: ').capitalize()
    dni= get_int_rango("Deme su D.N.I:", '[ERROR]Deme un D.N.I correcto', 13000000, 55000000, 6)
    salario = ingreso_float_rango("Deme su salario: ","Error ingrese salario valido",5000,1000000,5)
    telefono = input('FORMATO[11-NNNN-NNNN]\n Ingrese número su de telefono: ')
    while validar_telefono(telefono) == False:
        telefono = input('[ERROR]FORMATO[11-NNNN-NNNN]\n Ingrese número su de telefono: ')
    nuevo_empleado = Empleado(apellido_nombre,salario,dni,telefono)
    empleado_existente = False
    for i in range(len(lista_empleados)):
        if lista_empleados[i].dni == nuevo_empleado.dni:
            empleado_existente== True
            print("usuario ya existente")
            return False
    if empleado_existente == False:
        lista_empleados.append(nuevo_empleado)
        guardar_empleado(lista_empleados)
    return nuevo_empleado
def validar_patente(patente):
    patron = r'^[A-Z]{3}-\d{3}$'
    if re.match(patron, patente):
        return True
    else:
        return False

def alta_vehiculo(lista_vehiculos:list[Vehiculo]):
    marca = get_solo_string_rango('Ingrese marca del vehiculo: ','[ERROR] Ingrese marca de su vehículo válida:', 1,20,10).capitalize()
    modelo = get_solo_string_rango('Ingrese modelo del vehiculo: ', 'ERROR, Ingrese modelo del vehiculo válido: ', 1,20,4).capitalize()
    anio = get_int_rango('Ingrese el año de su vehiculo: ', 'ERROR, Ingrese año válido: ', 1800,2024,4)
    color =  get_solo_string_rango('Ingrese color del vehículo: ', '[ERROR] Ingrese color válido: ', 1,20,5).capitalize()
    patente =  input('FORMATO [XXX-NNN]\nIngrese patente del vehiculo: ')
    while validar_patente(patente) == False:
        patente =  input('FORMATO [XXX-NNN]\nIngrese patente del vehiculo: ')
    propietario = input("Deme nombre y apellido del propietario: ").capitalize()
    while validar_nombre_apellido(propietario) == False:
        propietario = input("Deme nombre y apellido del propietario: ").capitalize()
    nuevo_vehiculo = Vehiculo(marca,modelo,anio,color,patente, propietario)
    empleado_existente = False
    for i in range(len(lista_vehiculos)):
        if lista_vehiculos[i].Patente == nuevo_vehiculo.Patente:
            empleado_existente== True
            print("usuario ya existente")
            return False
    if empleado_existente == False:
        lista_vehiculos.append(nuevo_vehiculo)
        guardar_vehiculo(lista_vehiculos)
    return nuevo_vehiculo


