import utils as u
import union as p

def menu(consigna,lista_empleados,lista_vehiculos):
    opcion =  u.menu(consigna, "MENU")
    match opcion:
        case 0:
            print('Ha salido del programa.')
        case 1:
            p.listar_vehiculos(lista_vehiculos)
            
            menu(consigna,lista_empleados,lista_vehiculos)
        case 2:
            p.listar_empleados(lista_empleados)
            menu(consigna,lista_empleados,lista_vehiculos)
        case 3:
            if p.alta_empleado(lista_empleados):
                print('Ha dado de alta correctamente.')
            else:
                print('[ERROR] No ha podido dar de alta al empleado.')
            menu(consigna,lista_empleados,lista_vehiculos)
        case 4:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 5:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 6:
            if p.guardar_empleado(lista_empleados):
                print('Se ha guardado los cambios correctamente en el archivo.')
            else:
                print('Hubo un error al guardar los datos')
            menu(consigna,lista_empleados,lista_vehiculos)
        case 7:
            if p.alta_vehiculo(lista_vehiculos):
                print('Se ha dado de alta correctamente')
            else:
                print('Error en dar de alta.')
            menu(consigna,lista_empleados,lista_vehiculos)
        case 8:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 9:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 10:
            if p.guardar_vehiculo(lista_vehiculos):
                print('Se han guardado los cambios en el archivo')
            else:
                print("[ERROR] En guardar los datos en el archivo.")
            menu(consigna,lista_empleados,lista_vehiculos)
        case 11:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 12:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 13:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 14:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 15:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 16:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 17:
            menu(consigna,lista_empleados,lista_vehiculos)
        case 18:
            menu(consigna,lista_empleados,lista_vehiculos)

def main():
    consigna = ['VER VEHICULOS', 'VER EMPLEADOS', 'EMPLEADO ALTA', 'EMPLEADO BAJA', 'EMPLEADO MODIFICACION','GUARDAR EMPLEADOS.csv','VEHICULO ALTA']
    lista_empleados = p.get_empleado()
    lista_vehiculos = p.get_vehiculo()
    lista_empleados = p.ordenamiento_salario(lista_empleados)
    lista_vehiculos = p.ordenamiento_anio(lista_vehiculos)

    menu(consigna,lista_empleados,lista_vehiculos)
main()
